package com.mycompany.homework1;

/**
 * The base class for creating a node.
 */
public class Node<T> {
  T data;
  Node<T> next;
}
